package com.example.demo.controller;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Emprepo extends JpaRepository<Employee,Long> {

	//void deleteById(Long id);

	

}
