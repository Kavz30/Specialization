package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {
	@Autowired
	Empservice service;

	@RequestMapping("/")
	public ModelAndView dem(ModelAndView mv)
	{
	   mv.setViewName("index.jsp");
	   List<Employee> list=service.listemp();
	   mv.addObject("all", list);
	   return mv;
	}
	

	@RequestMapping(value="/save",method=RequestMethod.POST)
	public ModelAndView empsave(ModelAndView mv,Employee emp)
	
	{
	
		
		mv.setViewName("redirect:/");
		service.saveemp(emp);
		return mv;
		
	}
	@RequestMapping(value="/delete/{id}")
	public ModelAndView empdelete(@PathVariable("id") long eid,ModelAndView mv)
	{
		
		
		mv.setViewName("redirect:/");
		service.deleteemp(eid);
		return mv;
		
		
	}
	@RequestMapping(value="/edit")
	public ModelAndView empedit(@RequestParam("id") long id,ModelAndView mv)
	{
		
		
		mv.setViewName("welcome.jsp");
		mv.addObject("id", id);
		return mv;
		
		
	}


	
}
