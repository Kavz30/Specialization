package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {
	@Autowired
	Empservice service;

	@RequestMapping("/")
	public String dem()
	{
		return "index.jsp";
	}
	
	
	@RequestMapping("/print")
	public ModelAndView demo(@RequestParam("name") String name,ModelAndView mv)
	
	{
		mv=new ModelAndView();
		mv.addObject("Username", name);
		mv.setViewName("welcome.jsp");
		return mv;
	}

	@RequestMapping("/save")
	public ModelAndView empsave(ModelAndView mv,Employee emp)
	
	{
		mv=new ModelAndView();
		mv.addObject("empl",emp);
		mv.setViewName("welcome.jsp");
		service.saveemp(emp);
		return mv;
	}

	
}
